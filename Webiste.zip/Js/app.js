$(`.searchbar-btn`).click(
    function (){
        $(`.search-bar-container`).toggleClass(`show-bar`)
    }
)


$('.single-slide').slick({
    dots: true,
    infinite: false,
    // nextArrow: '.next_caro',
    // prevArrow: '.previous_caro',
    speed: 300,
    slidesToShow: 2,
    slidesToScroll: 2,
    responsive: [
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                infinite: true,
                dots: true
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
    ]
});



function show(x){
    $(`.faqs-${x}`).toggleClass(`activeFAQs`)
}
//Way Point
let windowHeight = $(window).height()

$(window).scroll(
    function () {
        currentHeight =$(this).scrollTop()
        if(currentHeight > windowHeight){
            $(`.food-header`).addClass(`navbar-change`)
        }
        else{
            $(`.food-header`).removeClass(`navbar-change`)
        }

    }
)


function setActive(currentSectionId) {
    $(`.nav-link`).removeClass(`active-Nav`)
    $(`.nav-link[href="#${currentSectionId}"]`).addClass(`active-Nav`)
console.log(`hello123`)
}

function addActive() {
    let currentSection = $(`section[id]`)
currentSection.waypoint(
    function (dierction) {
        if (dierction ==`down`){
            let currentSectionId = $(this.element).attr(`id`)
            console.log(currentSectionId)
            setActive(currentSectionId)
        }
    }
)
    currentSection.waypoint(
        function (direction) {
            if(direction == `up`){
                let currentSectionId = $(this.element).attr(`id`)
                setActive(currentSectionId)
            }
        }
    )
}


addActive()
$(window).on("load",function (){
    $(`.loader-container`).fadeOut(500,function (){$(this).remove()})
})
